package com.elsoproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElsoProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElsoProjectApplication.class, args);
	}

}
