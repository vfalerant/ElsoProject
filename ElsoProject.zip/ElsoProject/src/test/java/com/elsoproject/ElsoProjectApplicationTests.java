package com.elsoproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElsoProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
